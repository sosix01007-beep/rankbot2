"""
╔══════════════════════════════════════════════════════════╗
║        ALBION ONLINE — GUILD REGISTRATION BOT           ║
║  ระบบสมัครกิลแบบ Pop-up เลือกได้เลย                   ║
╚══════════════════════════════════════════════════════════╝
"""

import discord
from discord.ext import commands
from discord import app_commands
import os, sys, asyncio
from datetime import datetime, timezone, timedelta
from supabase import create_client

# ══════════════════════════════════════
# ENV
# ══════════════════════════════════════
def env(name, default="0"):
    return os.getenv(name, default) or default

DISCORD_TOKEN = env("DISCORD_TOKEN", "")
SUPABASE_URL  = env("SUPABASE_URL", "")
SUPABASE_KEY  = env("SUPABASE_KEY", "")

# Channel IDs
CH_APPLY      = int(env("CH_APPLY", 0))       # ห้องกดสมัคร
CH_REVIEW     = int(env("CH_REVIEW", 0))       # ห้องแอดมินเห็นใบสมัคร
CH_WELCOME    = int(env("CH_WELCOME", 0))      # ห้องต้อนรับสมาชิกใหม่
CH_LOG        = int(env("CH_LOG", 0))          # ห้อง log
CH_ADMIN      = int(env("CH_ADMIN", 0))        # ห้องแอดมิน
CH_SCREENSHOT = int(env("CH_SCREENSHOT", 0))  # ห้องแนบรูป IP
ADMIN_ROLE_ID = int(env("ADMIN_ROLE_ID", 0))  # Role แอดมิน

# Role IDs — ติดอัตโนมัติหลังสมัคร
ROLE_TANK     = int(env("ROLE_TANK", 0))
ROLE_HEALER   = int(env("ROLE_HEALER", 0))
ROLE_MELEE    = int(env("ROLE_MELEE", 0))
ROLE_RANGED   = int(env("ROLE_RANGED", 0))
ROLE_MAGIC    = int(env("ROLE_MAGIC", 0))
ROLE_GATHERER = int(env("ROLE_GATHERER", 0))
ROLE_CRAFTER  = int(env("ROLE_CRAFTER", 0))
ROLE_SCOUT    = int(env("ROLE_SCOUT", 0))
ROLE_MEMBER   = int(env("ROLE_MEMBER", 0))    # Role สมาชิกกิลทั่วไป

if not DISCORD_TOKEN:
    print("❌ NO TOKEN"); sys.exit(1)

# ══════════════════════════════════════
# SUPABASE
# ══════════════════════════════════════
_sb = None
def get_sb():
    global _sb
    if _sb is None:
        try: _sb = create_client(SUPABASE_URL, SUPABASE_KEY); print("✅ Supabase connected")
        except Exception as e: print(f"❌ Supabase: {e}")
    return _sb

def save_application(data: dict):
    try: get_sb().table("guild_applications").insert(data).execute(); return True
    except Exception as e: print(f"❌ save_application: {e}"); return False

def update_screenshot(uid: str, url: str):
    try:
        get_sb().table("guild_applications").update({"screenshot_url": url}).eq("discord_id", uid).eq("status", "pending").execute()
        return True
    except Exception as e: print(f"❌ update_screenshot: {e}"); return False

def get_application(uid: str):
    try:
        r = get_sb().table("guild_applications").select("*").eq("discord_id", uid).order("created_at", desc=True).limit(1).execute()
        return r.data[0] if r.data else None
    except: return None

def update_status(uid: str, status: str, reviewer: str = ""):
    try:
        get_sb().table("guild_applications").update({"status": status, "reviewed_by": reviewer, "reviewed_at": datetime.now(timezone.utc).isoformat()}).eq("discord_id", uid).execute()
        return True
    except: return False

# ══════════════════════════════════════
# CONFIG
# ══════════════════════════════════════
CFG = {
    "guild_name":    "Guild Name",
    "guild_desc":    "ยินดีต้อนรับสู่กิลของเรา!",
    "guild_image":   "",
    "guild_color":   0xc8a96e,
    "min_ip":        0,
    "auto_approve":  False,
}

# ══════════════════════════════════════
# TEXT CONFIG — แก้ข้อความในบอทได้เลยค่ะ
# ══════════════════════════════════════
TEXT = {
    # หน้าสมัครหลัก
    "apply_title":       "รับสมาชิกใหม่!",
    "apply_desc":        "กิลของเรายินดีต้อนรับทุกคนนะคะ!\n\n**กดปุ่มด้านล่างเพื่อสมัครได้เลยค่ะ!**",
    "apply_steps":       "1️⃣ บอกระดับประสบการณ์\n2️⃣ กรอกข้อมูลตัวละคร\n3️⃣ เลือกบทบาทที่ถนัด\n4️⃣ บอกเวลาที่เล่น",
    "apply_activities":  "👥 Group Dungeon | 🌍 Open World | 💰 Fame Farm\n🚪 Hellgate | 📦 Gathering",

    # คำถาม Step 1 — ประสบการณ์
    "exp_question":      "เล่น Albion Online มานานแค่ไหนแล้วคะ?",
    "exp_new_label":     "🆕 มือใหม่เลย ยังไม่รู้จักเกม",
    "exp_mid_label":     "📘 เล่นมาบ้างแล้ว (1–6 เดือน)",
    "exp_pro_label":     "🏆 มีประสบการณ์ (6+ เดือน)",

    # ข้อความต้อนรับมือใหม่
    "newbie_title":      "🎉 ยินดีต้อนรับมือใหม่!",
    "newbie_desc":       "ไม่ต้องกังวลนะคะ กิลเรายินดีสอนทุกอย่างค่ะ!\nแอดมินจะติดต่อกลับเร็วๆ นี้นะคะ 😊",

    # บทบาท
    "role_title":        "🛡️ เลือกบทบาทในกิล",
    "role_desc":         "เลือกบทบาทที่คุณถนัดได้เลยค่ะ (เลือกได้มากกว่า 1)",
    "role_tank":         "🛡️ Tank — แนวหน้า รับดาเมจ",
    "role_healer":       "💚 Healer — ฮีลทีม ดูแลพวก",
    "role_melee":        "⚔️ Melee DPS — ดาเมจระยะประชิด",
    "role_ranged":       "🏹 Ranged DPS — ดาเมจระยะไกล",
    "role_magic":        "🔮 Magic DPS — เวทย์/CC",
    "role_gatherer":     "⚒️ Gatherer — เก็บทรัพยากร",
    "role_crafter":      "🔨 Crafter — คราฟไอเทม",
    "role_scout":        "🗺️ Scout — สอดแนม",

    # กิจกรรม
    "act_title":         "🎮 เลือกกิจกรรมที่สนใจ",
    "act_desc":          "คุณสนใจทำอะไรบ้างในกิล? (เลือกได้หลายอย่าง)",
    "act_zvz":           "⚔️ ZvZ (Guild War)",
    "act_hellgate":      "🚪 Hellgate",
    "act_crystal":       "🏰 Crystal League",
    "act_corrupted":     "🗡️ Corrupted Dungeon",
    "act_dungeon":       "👥 Group Dungeon",
    "act_openpvp":       "🌍 Open World PvP",
    "act_fame":          "💰 Fame Farming",
    "act_economy":       "📦 Gathering/Crafting",

    # เวลาเล่น
    "time_title":        "⏰ ช่วงเวลาที่เล่น",
    "time_desc":         "เลือกช่วงเวลาที่คุณออนไลน์บ่อยค่ะ",

    # DM อนุมัติ
    "dm_approve_title":  "✅ ใบสมัครได้รับการอนุมัติแล้วค่ะ!",
    "dm_approve_desc":   "ยินดีต้อนรับเข้าสู่กิลนะคะ! แอดมินจะแนะนำขั้นตอนต่อไปให้ค่ะ 😊",

    # DM ปฏิเสธ
    "dm_reject_title":   "❌ ใบสมัครไม่ผ่านการอนุมัติค่ะ",
    "dm_reject_desc":    "สามารถพัฒนาและสมัครใหม่ได้ในภายหลังค่ะ!",

    # Welcome channel
    "welcome_msg":       "ขอต้อนรับสมาชิกใหม่เข้าสู่กิลค่ะ! 🎉",
}

# ══════════════════════════════════════
# BOT SETUP
# ══════════════════════════════════════
intents = discord.Intents.default()
intents.message_content = True
intents.members = True
bot = commands.Bot(command_prefix="!", intents=intents, help_command=None)

def is_admin(i: discord.Interaction):
    if i.user.guild_permissions.administrator: return True
    if ADMIN_ROLE_ID:
        role = discord.utils.get(i.guild.roles, id=ADMIN_ROLE_ID)
        return role and role in i.user.roles
    return False

def now_iso(): return datetime.now(timezone.utc).isoformat()

async def log_action(action, detail=None, color=0x95a5a6):
    try:
        ch = bot.get_channel(CH_LOG)
        if not ch or CH_LOG == 0: return
        embed = discord.Embed(description=f"**{action}**\n{detail or ''}", color=color)
        embed.set_footer(text=datetime.now().strftime('%d/%m %H:%M:%S'))
        await ch.send(embed=embed)
    except: pass

# ══════════════════════════════════════
# ROLE MAPPING
# ══════════════════════════════════════
ROLE_MAP = {
    "tank":     ("🛡️ Tank",       ROLE_TANK),
    "healer":   ("💚 Healer",     ROLE_HEALER),
    "melee":    ("⚔️ Melee DPS",  ROLE_MELEE),
    "ranged":   ("🏹 Ranged DPS", ROLE_RANGED),
    "magic":    ("🔮 Magic DPS",  ROLE_MAGIC),
    "gatherer": ("⚒️ Gatherer",   ROLE_GATHERER),
    "crafter":  ("🔨 Crafter",    ROLE_CRAFTER),
    "scout":    ("🗺️ Scout",      ROLE_SCOUT),
}

def get_activity_map():
    return {
        "zvz":       TEXT["act_zvz"],
        "hellgate":  TEXT["act_hellgate"],
        "crystal":   TEXT["act_crystal"],
        "corrupted": TEXT["act_corrupted"],
        "dungeon":   TEXT["act_dungeon"],
        "openpvp":   TEXT["act_openpvp"],
        "fame":      TEXT["act_fame"],
        "economy":   TEXT["act_economy"],
    }

def get_exp_map():
    return {
        "new": TEXT["exp_new_label"],
        "mid": TEXT["exp_mid_label"],
        "pro": TEXT["exp_pro_label"],
    }

TIME_MAP = {
    "morning":   "🌅 เช้า (6:00–12:00)",
    "afternoon": "🌞 บ่าย (12:00–18:00)",
    "evening":   "🌆 เย็น (18:00–22:00)",
    "night":     "🌙 ดึก (22:00–02:00)",
}

# ══════════════════════════════════════
# STEP 0: ถามประสบการณ์ก่อนเลย
# ══════════════════════════════════════
class Step0ExpView(discord.ui.View):
    def __init__(self): super().__init__(timeout=300)

    async def _pick(self, i: discord.Interaction, level: str):
        if level == "new":
            # มือใหม่ → เปิด modal ข้อมูลพื้นฐานแล้วส่งใบสมัครเลย
            await i.response.send_modal(Step1NewbieModal())
        else:
            # มีประสบการณ์ → เปิด modal ปกติ
            await i.response.send_modal(Step1Modal(level))

    @discord.ui.button(row=0, style=discord.ButtonStyle.secondary)
    async def btn_new(self, i: discord.Interaction, b: discord.ui.Button):
        await self._pick(i, "new")

    @discord.ui.button(row=0, style=discord.ButtonStyle.secondary)
    async def btn_mid(self, i: discord.Interaction, b: discord.ui.Button):
        await self._pick(i, "mid")

    @discord.ui.button(row=0, style=discord.ButtonStyle.secondary)
    async def btn_pro(self, i: discord.Interaction, b: discord.ui.Button):
        await self._pick(i, "pro")

    def __init_subclass__(cls, **kwargs): super().__init_subclass__(**kwargs)

    @classmethod
    def build(cls):
        view = cls()
        view.btn_new.label = TEXT["exp_new_label"]
        view.btn_mid.label = TEXT["exp_mid_label"]
        view.btn_pro.label = TEXT["exp_pro_label"]
        return view

# ── มือใหม่: Modal เบาๆ แค่ชื่อ + ชื่อเล่น ──
class Step1NewbieModal(discord.ui.Modal, title="📝 ข้อมูลพื้นฐาน"):
    username = discord.ui.TextInput(
        label="ชื่อตัวละครใน Albion Online",
        placeholder="เช่น DragonSlayer123",
        min_length=2, max_length=30
    )
    nickname = discord.ui.TextInput(
        label="ชื่อเล่นของคุณ",
        placeholder="เช่น โบ, มิ้น, เจมส์",
        min_length=1, max_length=20
    )

    async def on_submit(self, i: discord.Interaction):
        uid = str(i.user.id)
        # บันทึก DB ทันที — ไม่ต้องผ่าน step อื่น
        save_application({
            "discord_id":   uid,
            "discord_name": str(i.user),
            "albion_name":  self.username.value.strip(),
            "item_power":   self.nickname.value.strip(),
            "about":        "มือใหม่",
            "roles":        "new",
            "activities":   "",
            "experience":   "new",
            "playtimes":    "",
            "status":       "approved" if CFG["auto_approve"] else "pending",
            "created_at":   now_iso(),
        })

        # ติด Role Member อัตโนมัติ
        member = i.guild.get_member(int(uid))
        if member and ROLE_MEMBER != 0:
            role = discord.utils.get(i.guild.roles, id=ROLE_MEMBER)
            if role:
                try: await member.add_roles(role)
                except: pass

        app_data = {
            "username":      self.username.value.strip(),
            "nickname":      self.nickname.value.strip(),
            "prev_guild":    "ไม่มี (มือใหม่)",
            "role_text":     TEXT["exp_new_label"],
            "activity_text": "—",
            "exp_text":      TEXT["exp_new_label"],
            "time_text":     "—",
            "mention":       i.user.mention,
            "discord_name":  str(i.user),
            "avatar_url":    i.user.display_avatar.url,
        }

        # ส่ง embed ไปห้อง review พร้อมถามรูป
        await i.response.defer(ephemeral=True)
        await i.followup.send(
            embed=discord.Embed(
                title=TEXT["newbie_title"],
                description=TEXT["newbie_desc"],
                color=0x2ecc71
            ),
            view=ScreenshotView(uid, app_data),
            ephemeral=True
        )
        await log_action("NEW_APPLICATION", f"{i.user} | มือใหม่: {self.username.value.strip()}", 0x3498db)

# ══════════════════════════════════════
# STEP 1: MODAL — ชื่อในเกม + IP
# ══════════════════════════════════════
class Step1Modal(discord.ui.Modal, title="📝 ข้อมูลพื้นฐาน"):
    def __init__(self, exp_level: str = "mid"):
        super().__init__()
        self._exp_level = exp_level

    username = discord.ui.TextInput(
        label="ชื่อตัวละครใน Albion Online",
        placeholder="เช่น DragonSlayer123",
        min_length=2, max_length=30
    )
    item_power = discord.ui.TextInput(
        label="ชื่อเล่นของคุณ",
        placeholder="เช่น โบ, มิ้น, เจมส์",
        min_length=1, max_length=20,
        required=True
    )
    about = discord.ui.TextInput(
        label="เคยอยู่กิลไหนมาก่อน? (ไม่บังคับ)",
        placeholder="เช่น เคยอยู่กิล XYZ มา 2 เดือน หรือ ไม่เคยอยู่กิลเลย",
        style=discord.TextStyle.paragraph,
        required=False,
        max_length=200
    )

    async def on_submit(self, i: discord.Interaction):
        uid      = str(i.user.id)
        nickname = self.item_power.value.strip()   # ชื่อเล่น
        prev_guild = self.about.value.strip()      # กิลเก่า

        # เก็บข้อมูลชั่วคราวใน custom_id ของ view
        await i.response.send_message(
            embed=discord.Embed(
                title=TEXT["role_title"],
                description=TEXT["role_desc"],
                color=CFG["guild_color"]
            ).add_field(
                name="📖 คำอธิบายบทบาท",
                value=(
                    f"{TEXT['role_tank']}\n"
                    f"{TEXT['role_healer']}\n"
                    f"{TEXT['role_melee']}\n"
                    f"{TEXT['role_ranged']}\n"
                    f"{TEXT['role_magic']}\n"
                    f"{TEXT['role_gatherer']}\n"
                    f"{TEXT['role_crafter']}\n"
                    f"{TEXT['role_scout']}"
                ),
                inline=False
            ),
            view=Step2RoleView(uid, self.username.value.strip(), nickname, prev_guild, self._exp_level),
            ephemeral=True
        )

# ══════════════════════════════════════
# STEP 2: เลือกบทบาท
# ══════════════════════════════════════
class Step2RoleView(discord.ui.View):
    def __init__(self, uid, username, nickname, prev_guild, exp_level="mid"):
        super().__init__(timeout=300)
        self.uid        = uid
        self.username   = username
        self.nickname   = nickname
        self.prev_guild = prev_guild
        self.exp_level  = exp_level
        self.roles      = set()

    def toggle(self, role_key):
        if role_key in self.roles: self.roles.remove(role_key)
        else: self.roles.add(role_key)

    def get_label(self, role_key):
        base = ROLE_MAP[role_key][0]
        return f"✅ {base}" if role_key in self.roles else base

    @discord.ui.button(label="🛡️ Tank", style=discord.ButtonStyle.secondary, row=0)
    async def r_tank(self, i, b):
        self.toggle("tank"); b.label = self.get_label("tank")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="💚 Healer", style=discord.ButtonStyle.secondary, row=0)
    async def r_heal(self, i, b):
        self.toggle("healer"); b.label = self.get_label("healer")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="⚔️ Melee DPS", style=discord.ButtonStyle.secondary, row=0)
    async def r_melee(self, i, b):
        self.toggle("melee"); b.label = self.get_label("melee")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🏹 Ranged DPS", style=discord.ButtonStyle.secondary, row=1)
    async def r_range(self, i, b):
        self.toggle("ranged"); b.label = self.get_label("ranged")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🔮 Magic DPS", style=discord.ButtonStyle.secondary, row=1)
    async def r_magic(self, i, b):
        self.toggle("magic"); b.label = self.get_label("magic")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="⚒️ Gatherer", style=discord.ButtonStyle.secondary, row=1)
    async def r_gath(self, i, b):
        self.toggle("gatherer"); b.label = self.get_label("gatherer")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🔨 Crafter", style=discord.ButtonStyle.secondary, row=2)
    async def r_craft(self, i, b):
        self.toggle("crafter"); b.label = self.get_label("crafter")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🗺️ Scout", style=discord.ButtonStyle.secondary, row=2)
    async def r_scout(self, i, b):
        self.toggle("scout"); b.label = self.get_label("scout")
        await i.response.edit_message(view=self)

    @discord.ui.button(label="➡️ ต่อไป", style=discord.ButtonStyle.primary, row=2)
    async def next_step(self, i, b):
        if not self.roles:
            await i.response.send_message("❌ กรุณาเลือกบทบาทอย่างน้อย 1 อย่างค่ะ!", ephemeral=True); return
        await i.response.edit_message(
            embed=discord.Embed(
                title=TEXT["act_title"],
                description=TEXT["act_desc"],
                color=CFG["guild_color"]
            ).add_field(
                name="📖 คำอธิบาย",
                value=(
                    f"{TEXT['act_zvz']}\n"
                    f"{TEXT['act_hellgate']}\n"
                    f"{TEXT['act_crystal']}\n"
                    f"{TEXT['act_corrupted']}\n"
                    f"{TEXT['act_dungeon']}\n"
                    f"{TEXT['act_openpvp']}\n"
                    f"{TEXT['act_fame']}\n"
                    f"{TEXT['act_economy']}"
                ),
                inline=False
            ),
            view=Step3ActivityView(self.uid, self.username, self.nickname, self.prev_guild, self.roles, self.exp_level)
        )

# ══════════════════════════════════════
# STEP 3: เลือกกิจกรรม
# ══════════════════════════════════════
class Step3ActivityView(discord.ui.View):
    def __init__(self, uid, username, nickname, prev_guild, roles, exp_level="mid"):
        super().__init__(timeout=300)
        self.uid        = uid
        self.username   = username
        self.nickname   = nickname
        self.prev_guild = prev_guild
        self.roles      = roles
        self.exp_level  = exp_level
        self.activities = set()

    def toggle(self, key):
        if key in self.activities: self.activities.remove(key)
        else: self.activities.add(key)

    def get_label(self, key):
        base = get_activity_map()[key]
        return f"✅ {base}" if key in self.activities else base

    @discord.ui.button(label="⚔️ ZvZ", style=discord.ButtonStyle.secondary, row=0)
    async def a1(self, i, b): self.toggle("zvz"); b.label=self.get_label("zvz"); await i.response.edit_message(view=self)

    @discord.ui.button(label="🚪 Hellgate", style=discord.ButtonStyle.secondary, row=0)
    async def a2(self, i, b): self.toggle("hellgate"); b.label=self.get_label("hellgate"); await i.response.edit_message(view=self)

    @discord.ui.button(label="🏰 Crystal League", style=discord.ButtonStyle.secondary, row=0)
    async def a3(self, i, b): self.toggle("crystal"); b.label=self.get_label("crystal"); await i.response.edit_message(view=self)

    @discord.ui.button(label="🗡️ Corrupted", style=discord.ButtonStyle.secondary, row=1)
    async def a4(self, i, b): self.toggle("corrupted"); b.label=self.get_label("corrupted"); await i.response.edit_message(view=self)

    @discord.ui.button(label="👥 Group Dungeon", style=discord.ButtonStyle.secondary, row=1)
    async def a5(self, i, b): self.toggle("dungeon"); b.label=self.get_label("dungeon"); await i.response.edit_message(view=self)

    @discord.ui.button(label="🌍 Open World PvP", style=discord.ButtonStyle.secondary, row=1)
    async def a6(self, i, b): self.toggle("openpvp"); b.label=self.get_label("openpvp"); await i.response.edit_message(view=self)

    @discord.ui.button(label="💰 Fame Farming", style=discord.ButtonStyle.secondary, row=2)
    async def a7(self, i, b): self.toggle("fame"); b.label=self.get_label("fame"); await i.response.edit_message(view=self)

    @discord.ui.button(label="📦 Gathering/Crafting", style=discord.ButtonStyle.secondary, row=2)
    async def a8(self, i, b): self.toggle("economy"); b.label=self.get_label("economy"); await i.response.edit_message(view=self)

    @discord.ui.button(label="➡️ ต่อไป", style=discord.ButtonStyle.primary, row=2)
    async def next_step(self, i, b):
        if not self.activities:
            await i.response.send_message("❌ กรุณาเลือกกิจกรรมอย่างน้อย 1 อย่างค่ะ!", ephemeral=True); return
        await i.response.edit_message(
            embed=discord.Embed(
                title="📊 ประสบการณ์และเวลาเล่น",
                description="บอกเราเพิ่มเติมเกี่ยวกับตัวคุณค่ะ",
                color=CFG["guild_color"]
            ),
            view=Step4ExpTimeView(self.uid, self.username, self.nickname, self.prev_guild, self.roles, self.activities, self.exp_level)
        )

# ══════════════════════════════════════
# STEP 4: ประสบการณ์ + ช่วงเวลาเล่น
# ══════════════════════════════════════
class Step4ExpTimeView(discord.ui.View):
    def __init__(self, uid, username, nickname, prev_guild, roles, activities, exp_level="mid"):
        super().__init__(timeout=300)
        self.uid        = uid
        self.username   = username
        self.nickname   = nickname
        self.prev_guild = prev_guild
        self.roles      = roles
        self.activities = activities
        self.exp        = exp_level   # pre-set จาก Step0
        self.times      = set()

    @discord.ui.button(label=TEXT["exp_new_label"], style=discord.ButtonStyle.secondary, row=0)
    async def e1(self, i, b):
        self.exp = "new"
        for btn in self.children:
            if hasattr(btn, 'custom_id') or True:
                if btn.label.startswith(("🆕","📘","🏆")):
                    btn.style = discord.ButtonStyle.secondary
        b.style = discord.ButtonStyle.primary
        await i.response.edit_message(view=self)

    @discord.ui.button(label=TEXT["exp_mid_label"], style=discord.ButtonStyle.secondary, row=0)
    async def e2(self, i, b):
        self.exp = "mid"
        for btn in self.children:
            if btn.label.startswith(("🆕","📘","🏆")):
                btn.style = discord.ButtonStyle.secondary
        b.style = discord.ButtonStyle.primary
        await i.response.edit_message(view=self)

    @discord.ui.button(label=TEXT["exp_pro_label"], style=discord.ButtonStyle.secondary, row=0)
    async def e3(self, i, b):
        self.exp = "pro"
        for btn in self.children:
            if btn.label.startswith(("🆕","📘","🏆")):
                btn.style = discord.ButtonStyle.secondary
        b.style = discord.ButtonStyle.primary
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🌅 เช้า", style=discord.ButtonStyle.secondary, row=1)
    async def t1(self, i, b):
        if "morning" in self.times: self.times.remove("morning"); b.style=discord.ButtonStyle.secondary
        else: self.times.add("morning"); b.style=discord.ButtonStyle.success
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🌞 บ่าย", style=discord.ButtonStyle.secondary, row=1)
    async def t2(self, i, b):
        if "afternoon" in self.times: self.times.remove("afternoon"); b.style=discord.ButtonStyle.secondary
        else: self.times.add("afternoon"); b.style=discord.ButtonStyle.success
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🌆 เย็น", style=discord.ButtonStyle.secondary, row=1)
    async def t3(self, i, b):
        if "evening" in self.times: self.times.remove("evening"); b.style=discord.ButtonStyle.secondary
        else: self.times.add("evening"); b.style=discord.ButtonStyle.success
        await i.response.edit_message(view=self)

    @discord.ui.button(label="🌙 ดึก", style=discord.ButtonStyle.secondary, row=1)
    async def t4(self, i, b):
        if "night" in self.times: self.times.remove("night"); b.style=discord.ButtonStyle.secondary
        else: self.times.add("night"); b.style=discord.ButtonStyle.success
        await i.response.edit_message(view=self)

    @discord.ui.button(label="✅ ส่งใบสมัคร", style=discord.ButtonStyle.success, row=2)
    async def submit(self, i: discord.Interaction, b):
        if not self.exp:
            await i.response.send_message("❌ กรุณาเลือกระดับประสบการณ์ค่ะ!", ephemeral=True); return
        if not self.times:
            await i.response.send_message("❌ กรุณาเลือกช่วงเวลาเล่นอย่างน้อย 1 อย่างค่ะ!", ephemeral=True); return
        await i.response.defer(ephemeral=True)
        await submit_application(i, self.uid, self.username, self.nickname, self.prev_guild, self.roles, self.activities, self.exp, self.times)

# ══════════════════════════════════════
# HELPER — ส่ง embed ครบไปห้อง CH_REVIEW
# ══════════════════════════════════════
async def _send_review_embed(guild, uid: str, d: dict, img_url: str | None):
    review_ch = bot.get_channel(CH_REVIEW)
    if not review_ch or CH_REVIEW == 0:
        return

    embed = discord.Embed(
        title=f"📋 ใบสมัครใหม่ — {d['username']}",
        color=0xf0c040 if not CFG["auto_approve"] else 0x2ecc71
    )
    embed.set_thumbnail(url=d["avatar_url"])
    embed.add_field(name="👤 Discord",        value=f"{d['mention']}\n`{d['discord_name']}`", inline=True)
    embed.add_field(name="🗡️ Albion Name",    value=f"**{d['username']}**",                   inline=True)
    embed.add_field(name="🏷️ ชื่อเล่น",        value=d["nickname"],                            inline=True)
    embed.add_field(name="🛡️ บทบาท",          value=d["role_text"],                           inline=False)
    embed.add_field(name="🎮 กิจกรรม",        value=d["activity_text"],                       inline=False)
    embed.add_field(name="📊 ประสบการณ์",     value=d["exp_text"],                            inline=True)
    embed.add_field(name="⏰ เวลาเล่น",       value=d["time_text"],                           inline=True)
    if d.get("prev_guild"):
        embed.add_field(name="🏰 กิลเก่า",     value=d["prev_guild"],                          inline=False)
    if img_url:
        embed.set_image(url=img_url)
        embed.add_field(name="🖼️ สกรีนช็อต IP", value="✅ แนบแล้ว", inline=True)
    else:
        embed.add_field(name="🖼️ สกรีนช็อต IP", value="❌ ไม่มี",   inline=True)
    embed.set_footer(text=f"ID: {uid} • {datetime.now().strftime('%d/%m/%Y %H:%M')}")

    if CFG["auto_approve"]:
        await review_ch.send(embed=embed)
    else:
        await review_ch.send(embed=embed, view=ReviewActionView(uid, d["username"], d["mention"]))

# ══════════════════════════════════════
# PENDING APPLICATIONS — รอรูปก่อนส่ง review
# ══════════════════════════════════════
_pending: dict[str, dict] = {}   # uid -> app_data รอรูป

# ══════════════════════════════════════
# SUBMIT APPLICATION
# ══════════════════════════════════════
async def submit_application(i, uid, username, nickname, prev_guild, roles, activities, exp, times):
    guild = i.guild

    role_text     = ", ".join([ROLE_MAP[r][0] for r in roles])
    activity_text = ", ".join([get_activity_map()[a] for a in activities]) if activities else "—"
    exp_text      = get_exp_map().get(exp, exp)
    time_text     = ", ".join([TIME_MAP[t] for t in times]) if times else "—"

    # บันทึก DB (status = waiting_screenshot ก่อน)
    save_application({
        "discord_id":   uid,
        "discord_name": str(i.user),
        "albion_name":  username,
        "item_power":   nickname,
        "about":        prev_guild,
        "roles":        ",".join(roles) if roles else "new",
        "activities":   ",".join(activities),
        "experience":   exp,
        "playtimes":    ",".join(times),
        "status":       "waiting_screenshot",
        "created_at":   now_iso(),
    })

    # เก็บข้อมูลไว้รอรูป
    _pending[uid] = {
        "username":      username,
        "nickname":      nickname,
        "prev_guild":    prev_guild,
        "role_text":     role_text,
        "activity_text": activity_text,
        "exp_text":      exp_text,
        "time_text":     time_text,
        "mention":       i.user.mention,
        "discord_name":  str(i.user),
        "avatar_url":    i.user.display_avatar.url,
        "roles_raw":     list(roles),
        "guild_id":      i.guild.id,
    }

    # ─── แจ้งผู้สมัครให้ไปแนบรูปที่ห้อง CH_SCREENSHOT ───
    screenshot_ch = bot.get_channel(CH_SCREENSHOT)
    ch_mention    = screenshot_ch.mention if screenshot_ch else f"<#{CH_SCREENSHOT}>"

    await i.followup.send(
        embed=discord.Embed(
            title="📷 ขั้นตอนสุดท้าย — แนบสกรีนช็อต Item Power",
            description=(
                f"กรุณาไปที่ห้อง {ch_mention} แล้ว**ส่งรูปสกรีนช็อต IP** ของคุณในห้องนั้นค่ะ\n\n"
                "📌 ถ่ายที่หน้าตัวละครให้เห็นตัวเลข IP ชัดเจนนะคะ\n"
                "✅ บอทจะรับรูปและส่งใบสมัครให้อัตโนมัติเลยค่ะ"
            ),
            color=CFG["guild_color"]
        ),
        ephemeral=True
    )
    await log_action("PENDING_SCREENSHOT", f"{i.user} | Albion: {username}", 0xf39c12)


@bot.event
async def on_message(message: discord.Message):
    """จับรูปในห้อง CH_SCREENSHOT แล้วส่ง embed ไปห้อง review"""
    if message.author.bot: return
    await bot.process_commands(message)

    if CH_SCREENSHOT == 0 or message.channel.id != CH_SCREENSHOT: return
    if not message.attachments: return

    uid = str(message.author.id)
    if uid not in _pending: return   # ยังไม่มีใบสมัครรอ

    att = message.attachments[0]
    if not att.content_type or not att.content_type.startswith("image/"): return

    img_url  = att.url
    app_data = _pending.pop(uid)

    # ลบรูปออกจากห้องแนบรูปให้สะอาด
    try: await message.delete()
    except: pass

    # อัปเดต DB — screenshot + status pending
    update_screenshot(uid, img_url)
    get_sb().table("guild_applications").update({"status": "pending"}).eq("discord_id", uid).eq("status", "waiting_screenshot").execute()

    # ส่ง embed ครบ + รูป ไปห้อง review
    guild = bot.get_guild(app_data["guild_id"])
    await _send_review_embed(guild, uid, app_data, img_url)

    # DM แจ้งผู้สมัคร
    try:
        member = guild.get_member(int(uid))
        if member:
            await member.send(embed=discord.Embed(
                title="✅ ส่งใบสมัครเรียบร้อยแล้วค่ะ!",
                description="รอแอดมินตรวจสอบและแจ้งผลให้นะคะ 😊",
                color=0x2ecc71
            ))
    except: pass

    await log_action("NEW_APPLICATION", f"{message.author} | Albion: {app_data['username']} | แนบรูปแล้ว", 0x3498db)

# ══════════════════════════════════════
# REVIEW ACTION VIEW (แอดมินอนุมัติ/ปฏิเสธ)
# ══════════════════════════════════════
class ReviewActionView(discord.ui.View):
    def __init__(self, uid, albion_name, applicant):
        super().__init__(timeout=None)
        self.uid          = uid
        self.albion_name  = albion_name
        self.applicant    = applicant

    @discord.ui.button(label="✅ อนุมัติ", style=discord.ButtonStyle.success, custom_id="review_approve")
    async def approve(self, i: discord.Interaction, b):
        if not is_admin(i):
            await i.response.send_message("❌ ไม่มีสิทธิ์ค่ะ!", ephemeral=True); return
        await i.response.defer()
        update_status(self.uid, "approved", str(i.user))

        member = i.guild.get_member(int(self.uid))

        # ─── ดึงข้อมูลจาก DB เพื่อเอา nickname + roles ───
        app = get_application(self.uid)
        nickname   = app.get("item_power", "") if app else ""   # ชื่อเล่น
        roles_raw  = (app.get("roles", "") if app else "").split(",")

        # ─── เปลี่ยนชื่อ Discord เป็น "ชื่อเล่น | ชื่อ Albion" ───
        if member and nickname:
            try:
                new_nick = f"{nickname} | {self.albion_name}"
                await member.edit(nick=new_nick[:32])  # Discord จำกัด 32 ตัว
            except: pass

        # ─── ติดยศตามบทบาทที่เลือก + Role Member ───
        if member:
            roles_to_add = []
            for role_key in roles_raw:
                role_key = role_key.strip()
                if role_key in ROLE_MAP and ROLE_MAP[role_key][1] != 0:
                    r = discord.utils.get(i.guild.roles, id=ROLE_MAP[role_key][1])
                    if r: roles_to_add.append(r)
            if ROLE_MEMBER != 0:
                r = discord.utils.get(i.guild.roles, id=ROLE_MEMBER)
                if r: roles_to_add.append(r)
            if roles_to_add:
                try: await member.add_roles(*roles_to_add)
                except: pass

        # ─── DM แจ้งผล ───
        if member:
            try:
                dm_embed = discord.Embed(
                    title=TEXT["dm_approve_title"],
                    description=f"{TEXT['dm_approve_desc']}\n\n{CFG['guild_desc']}",
                    color=0x2ecc71
                )
                dm_embed.add_field(name="🗡️ Albion Name", value=self.albion_name, inline=True)
                dm_embed.add_field(name="💡 ถัดไป", value="เข้าไปแนะนำตัวในห้องทั่วไปได้เลยนะคะ!", inline=False)
                if CFG["guild_image"]: dm_embed.set_image(url=CFG["guild_image"])
                await member.send(embed=dm_embed)
            except: pass

        # ─── ส่งห้อง Welcome ───
        welcome_ch = bot.get_channel(CH_WELCOME)
        if welcome_ch and CH_WELCOME != 0 and member:
            display = member.display_name
            wembed = discord.Embed(
                title="⚔️ ยินดีต้อนรับสมาชิกใหม่!",
                description=f"ขอต้อนรับ {member.mention} (**{self.albion_name}**) {TEXT['welcome_msg']}",
                color=CFG["guild_color"]
            )
            wembed.set_thumbnail(url=member.display_avatar.url)
            if CFG["guild_image"]: wembed.set_image(url=CFG["guild_image"])
            await welcome_ch.send(embed=wembed)

        # ─── อัปเดต embed ───
        new_embed = i.message.embeds[0]
        new_embed.color = 0x2ecc71
        new_embed.set_footer(text=f"✅ อนุมัติโดย {i.user} • {datetime.now().strftime('%d/%m/%Y %H:%M')}")
        await i.message.edit(embed=new_embed, view=None)
        await log_action("APPROVE", f"{self.albion_name} อนุมัติโดย {i.user}", 0x2ecc71)

    @discord.ui.button(label="❌ ปฏิเสธ", style=discord.ButtonStyle.danger, custom_id="review_reject")
    async def reject(self, i: discord.Interaction, b):
        if not is_admin(i):
            await i.response.send_message("❌ ไม่มีสิทธิ์ค่ะ!", ephemeral=True); return
        await i.response.send_modal(RejectReasonModal(self.uid, self.albion_name, i.message))

    @discord.ui.button(label="🔍 ดูโปรไฟล์", style=discord.ButtonStyle.secondary, custom_id="review_profile")
    async def view_profile(self, i: discord.Interaction, b):
        app = get_application(self.uid)
        if not app: await i.response.send_message("❌ ไม่พบใบสมัครค่ะ!", ephemeral=True); return
        embed = discord.Embed(title=f"📋 ใบสมัคร — {app['albion_name']}", color=CFG["guild_color"])
        embed.add_field(name="Discord", value=f"<@{app['discord_id']}>", inline=True)
        embed.add_field(name="Status", value=app.get("status","pending"), inline=True)
        embed.add_field(name="สมัครเมื่อ", value=app.get("created_at","?")[:10], inline=True)
        await i.response.send_message(embed=embed, ephemeral=True)

class RejectReasonModal(discord.ui.Modal, title="❌ เหตุผลที่ปฏิเสธ"):
    reason = discord.ui.TextInput(
        label="เหตุผล (จะส่งถึงผู้สมัครทาง DM)",
        style=discord.TextStyle.paragraph,
        placeholder="เช่น IP ต่ำเกินไป / บทบาทไม่ตรงกับที่กิลต้องการ",
        max_length=300
    )

    def __init__(self, uid, albion_name, message):
        super().__init__()
        self.uid         = uid
        self.albion_name = albion_name
        self.message     = message

    async def on_submit(self, i: discord.Interaction):
        await i.response.defer()
        update_status(self.uid, "rejected", str(i.user))
        try:
            member = i.guild.get_member(int(self.uid))
            if member:
                dm_embed = discord.Embed(
                    title="❌ ใบสมัครของคุณไม่ผ่านการอนุมัติค่ะ",
                    description=f"**เหตุผล:**\n{self.reason.value}\n\nสามารถพัฒนาและสมัครใหม่ได้ในภายหลังค่ะ!",
                    color=0xe74c3c
                )
                await member.send(embed=dm_embed)
        except: pass
        new_embed = self.message.embeds[0]
        new_embed.color = 0xe74c3c
        new_embed.set_footer(text=f"❌ ปฏิเสธโดย {i.user} • {datetime.now().strftime('%d/%m/%Y %H:%M')}")
        await self.message.edit(embed=new_embed, view=None)
        await log_action("REJECT", f"{self.albion_name} ปฏิเสธโดย {i.user} — {self.reason.value}", 0xe74c3c)

# ══════════════════════════════════════
# SCREENSHOT UPLOAD VIEW
# ══════════════════════════════════════
# Modal รับ URL รูป — วิธีเดียวที่ทำงานได้กับ ephemeral
# ══════════════════════════════════════
# APPLY VIEW — ปุ่มสมัครหน้าหลัก
# ══════════════════════════════════════
class ApplyView(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)

    @discord.ui.button(label="⚔️ สมัครเข้ากิล", style=discord.ButtonStyle.danger, custom_id="guild_apply")
    async def apply(self, i: discord.Interaction, b):
        app = get_application(str(i.user.id))
        if app and app.get("status") == "pending":
            await i.response.send_message("⏳ ใบสมัครของคุณกำลังรอการอนุมัติอยู่ค่ะ!", ephemeral=True); return
        if app and app.get("status") == "approved":
            await i.response.send_message("✅ คุณเป็นสมาชิกกิลอยู่แล้วค่ะ!", ephemeral=True); return
        await i.response.send_message(
            embed=discord.Embed(
                title=TEXT["exp_question"],
                description="เลือกได้เลยค่ะ 👇",
                color=CFG["guild_color"]
            ),
            view=Step0ExpView.build(),
            ephemeral=True
        )

def make_apply_embed():
    embed = discord.Embed(
        title=f"⚔️ {CFG['guild_name']} — {TEXT['apply_title']}",
        description=f"{CFG['guild_desc']}\n\n{TEXT['apply_desc']}\n\n📋 **ขั้นตอน:**\n{TEXT['apply_steps']}",
        color=CFG["guild_color"]
    )
    embed.add_field(name="🎮 กิจกรรมของกิล", value=TEXT["apply_activities"], inline=False)
    if CFG["min_ip"] > 0:
        embed.add_field(name="⚡ Item Power ขั้นต่ำ", value=f"`{CFG['min_ip']} IP`", inline=True)
    if CFG["guild_image"]:
        embed.set_image(url=CFG["guild_image"])
    embed.set_footer(text="Albion Online Guild Recruitment Bot")
    return embed

# ══════════════════════════════════════
# ADMIN PANEL
# ══════════════════════════════════════
class GuildAdminPanel(discord.ui.View):
    def __init__(self): super().__init__(timeout=300)

    @discord.ui.button(label="📺 ส่งหน้าสมัคร", style=discord.ButtonStyle.primary, row=0)
    async def send_apply(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        if CH_APPLY == 0: await i.response.send_message("❌ ยังไม่ตั้ง CH_APPLY ค่ะ!", ephemeral=True); return
        ch = i.guild.get_channel(CH_APPLY)
        if not ch: await i.response.send_message("❌ หาห้องไม่เจอค่ะ!", ephemeral=True); return
        await ch.purge(limit=5)
        await ch.send(embed=make_apply_embed(), view=ApplyView())
        await i.response.send_message(f"✅ ส่งหน้าสมัครไปที่ {ch.mention} แล้วค่ะ!", ephemeral=True)

    @discord.ui.button(label="⚙️ ตั้งค่ากิล", style=discord.ButtonStyle.primary, row=0)
    async def guild_cfg(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        await i.response.send_modal(GuildCfgModal())

    @discord.ui.button(label="📋 ดูใบสมัครทั้งหมด", style=discord.ButtonStyle.secondary, row=1)
    async def list_apps(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        await i.response.defer(ephemeral=True)
        try:
            res = get_sb().table("guild_applications").select("*").order("created_at", desc=True).limit(20).execute()
            apps = res.data or []
            if not apps: await i.followup.send("ยังไม่มีใบสมัครค่ะ!", ephemeral=True); return
            lines = []
            for a in apps:
                status_emoji = {"pending":"⏳","approved":"✅","rejected":"❌"}.get(a.get("status","pending"),"❓")
                lines.append(f"{status_emoji} **{a['albion_name']}** — <@{a['discord_id']}> | {a.get('created_at','?')[:10]}")
            embed = discord.Embed(title=f"📋 ใบสมัครทั้งหมด ({len(apps)})", description="\n".join(lines), color=CFG["guild_color"])
            await i.followup.send(embed=embed, ephemeral=True)
        except Exception as e: await i.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="📊 สถิติ", style=discord.ButtonStyle.secondary, row=1)
    async def stats(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        await i.response.defer(ephemeral=True)
        try:
            res  = get_sb().table("guild_applications").select("*").execute()
            apps = res.data or []
            pending  = sum(1 for a in apps if a.get("status")=="pending")
            approved = sum(1 for a in apps if a.get("status")=="approved")
            rejected = sum(1 for a in apps if a.get("status")=="rejected")
            role_count = {}
            for a in apps:
                for r in (a.get("roles","")).split(","):
                    if r: role_count[r] = role_count.get(r,0)+1
            embed = discord.Embed(title="📊 สถิติการสมัครกิล", color=CFG["guild_color"])
            embed.add_field(name="⏳ รออนุมัติ", value=f"`{pending}`", inline=True)
            embed.add_field(name="✅ อนุมัติแล้ว", value=f"`{approved}`", inline=True)
            embed.add_field(name="❌ ปฏิเสธ", value=f"`{rejected}`", inline=True)
            role_txt = "\n".join([f"{ROLE_MAP[r][0]}: `{c}`" for r,c in sorted(role_count.items(), key=lambda x: -x[1]) if r in ROLE_MAP])
            if role_txt: embed.add_field(name="🛡️ บทบาทยอดนิยม", value=role_txt, inline=False)
            await i.followup.send(embed=embed, ephemeral=True)
        except Exception as e: await i.followup.send(f"❌ {e}", ephemeral=True)

    @discord.ui.button(label="✏️ แก้ข้อความบอท", style=discord.ButtonStyle.primary, row=2)
    async def edit_text(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        await i.response.send_modal(TextCfgModal1())

    @discord.ui.button(label="🔄 Toggle Auto Approve", style=discord.ButtonStyle.danger, row=2)
    async def toggle_auto(self, i, b):
        if not is_admin(i): await i.response.send_message("❌", ephemeral=True); return
        CFG["auto_approve"] = not CFG["auto_approve"]
        status = "เปิด ✅" if CFG["auto_approve"] else "ปิด ❌"
        await i.response.send_message(f"🔄 Auto Approve: **{status}**\n{'อนุมัติอัตโนมัติทันที' if CFG['auto_approve'] else 'รอแอดมินอนุมัติ'}", ephemeral=True)


class TextCfgModal1(discord.ui.Modal, title="✏️ แก้ข้อความ (1/2) — หน้าสมัคร"):
    apply_title = discord.ui.TextInput(label="หัวเรื่องหน้าสมัคร", max_length=60)
    apply_desc  = discord.ui.TextInput(label="คำอธิบายหน้าสมัคร", style=discord.TextStyle.paragraph, max_length=300)
    apply_steps = discord.ui.TextInput(label="ขั้นตอนการสมัคร", style=discord.TextStyle.paragraph, max_length=300)
    apply_acts  = discord.ui.TextInput(label="กิจกรรมกิล (แสดงในหน้าสมัคร)", style=discord.TextStyle.paragraph, max_length=200)
    exp_q       = discord.ui.TextInput(label="คำถามประสบการณ์", max_length=80)

    def __init__(self):
        super().__init__()
        self.apply_title.default = TEXT["apply_title"]
        self.apply_desc.default  = TEXT["apply_desc"]
        self.apply_steps.default = TEXT["apply_steps"]
        self.apply_acts.default  = TEXT["apply_activities"]
        self.exp_q.default       = TEXT["exp_question"]

    async def on_submit(self, i: discord.Interaction):
        TEXT["apply_title"]      = self.apply_title.value
        TEXT["apply_desc"]       = self.apply_desc.value
        TEXT["apply_steps"]      = self.apply_steps.value
        TEXT["apply_activities"] = self.apply_acts.value
        TEXT["exp_question"]     = self.exp_q.value
        await i.response.send_message(
            embed=discord.Embed(title="✅ บันทึกแล้ว! ต่อไปแก้ข้อความชุดที่ 2 ได้เลยค่ะ", color=0x2ecc71),
            view=_TextCfg2Btn(), ephemeral=True
        )

class _TextCfg2Btn(discord.ui.View):
    def __init__(self): super().__init__(timeout=60)
    @discord.ui.button(label="✏️ แก้ข้อความ (2/2)", style=discord.ButtonStyle.primary)
    async def go(self, i, b): await i.response.send_modal(TextCfgModal2())

class TextCfgModal2(discord.ui.Modal, title="✏️ แก้ข้อความ (2/2) — ป้ายชื่อ & DM"):
    exp_new  = discord.ui.TextInput(label="ป้าย: มือใหม่",          max_length=50)
    exp_mid  = discord.ui.TextInput(label="ป้าย: กลาง",             max_length=50)
    exp_pro  = discord.ui.TextInput(label="ป้าย: มีประสบการณ์",     max_length=50)
    newbie_t = discord.ui.TextInput(label="ข้อความต้อนรับมือใหม่ (title)", max_length=80)
    newbie_d = discord.ui.TextInput(label="ข้อความต้อนรับมือใหม่ (body)",  style=discord.TextStyle.paragraph, max_length=300)

    def __init__(self):
        super().__init__()
        self.exp_new.default  = TEXT["exp_new_label"]
        self.exp_mid.default  = TEXT["exp_mid_label"]
        self.exp_pro.default  = TEXT["exp_pro_label"]
        self.newbie_t.default = TEXT["newbie_title"]
        self.newbie_d.default = TEXT["newbie_desc"]

    async def on_submit(self, i: discord.Interaction):
        TEXT["exp_new_label"] = self.exp_new.value
        TEXT["exp_mid_label"] = self.exp_mid.value
        TEXT["exp_pro_label"] = self.exp_pro.value
        TEXT["newbie_title"]  = self.newbie_t.value
        TEXT["newbie_desc"]   = self.newbie_d.value
        await i.response.send_message(
            embed=discord.Embed(
                title="✅ บันทึกข้อความทั้งหมดแล้วค่ะ!",
                description="กด **📺 ส่งหน้าสมัคร** ใหม่เพื่อให้ข้อความอัปเดตนะคะ",
                color=0x2ecc71
            ),
            ephemeral=True
        )

class GuildCfgModal(discord.ui.Modal, title="⚙️ ตั้งค่ากิล"):
    name_  = discord.ui.TextInput(label="ชื่อกิล", default="Guild Name", max_length=50)
    desc_  = discord.ui.TextInput(label="คำอธิบายกิล", style=discord.TextStyle.paragraph, max_length=300, default="ยินดีต้อนรับสู่กิลของเรา!")
    image_ = discord.ui.TextInput(label="URL รูปภาพกิล (ปล่อยว่าง=ไม่มี)", required=False, max_length=500)
    min_ip_= discord.ui.TextInput(label="Item Power ขั้นต่ำ (0=ไม่จำกัด)", default="0", max_length=6)

    async def on_submit(self, i):
        try:
            CFG["guild_name"]  = self.name_.value.strip()
            CFG["guild_desc"]  = self.desc_.value.strip()
            CFG["guild_image"] = self.image_.value.strip()
            CFG["min_ip"]      = int(self.min_ip_.value or "0")
            embed = discord.Embed(title="✅ บันทึกแล้วค่ะ!", color=0x2ecc71)
            embed.add_field(name="ชื่อกิล", value=CFG["guild_name"], inline=True)
            embed.add_field(name="Min IP", value=str(CFG["min_ip"]) if CFG["min_ip"] > 0 else "ไม่จำกัด", inline=True)
            embed.add_field(name="รูปภาพ", value="✅ ตั้งแล้ว" if CFG["guild_image"] else "❌ ไม่มี", inline=True)
            embed.add_field(name="ต่อไป", value="กด **📺 ส่งหน้าสมัคร** เพื่ออัปเดตค่ะ!", inline=False)
            await i.response.send_message(embed=embed, ephemeral=True)
        except ValueError: await i.response.send_message("❌ Min IP ต้องเป็นตัวเลขค่ะ!", ephemeral=True)

# ══════════════════════════════════════
# EVENTS
# ══════════════════════════════════════
@bot.event
async def on_ready():
    print(f"✅ Guild Bot ONLINE: {bot.user}")
    bot.add_view(ApplyView())
    bot.add_view(ReviewActionView("0","",""))
    try:
        synced = await bot.tree.sync()
        print(f"✅ Slash synced: {len(synced)}")
    except Exception as e: print(f"❌ Sync: {e}")

# ══════════════════════════════════════
# SLASH COMMANDS
# ══════════════════════════════════════
@bot.tree.command(name="กิลแอดมิน", description="เปิด Guild Admin Panel")
async def guild_admin(i: discord.Interaction):
    if not is_admin(i): await i.response.send_message("❌ ไม่มีสิทธิ์ค่ะ!", ephemeral=True); return
    embed = discord.Embed(
        title="⚔️ Guild Admin Panel",
        description="จัดการระบบสมัครกิล Albion Online ได้ที่นี่ค่ะ",
        color=CFG["guild_color"]
    )
    embed.add_field(name="📺 ส่งหน้าสมัคร", value="ส่งปุ่มสมัครไปห้องที่กำหนด", inline=True)
    embed.add_field(name="⚙️ ตั้งค่ากิล", value="ชื่อ/คำอธิบาย/รูป/Min IP", inline=True)
    embed.add_field(name="📋 ดูใบสมัคร", value="ดูรายการใบสมัครทั้งหมด", inline=True)
    embed.add_field(name="📊 สถิติ", value="จำนวนสมาชิก/บทบาท", inline=True)
    embed.add_field(name="🔄 Auto Approve", value=f"ตอนนี้: {'เปิด ✅' if CFG['auto_approve'] else 'ปิด ❌'}", inline=True)
    embed.set_footer(text="เฉพาะแอดมิน • เห็นแค่คุณ")
    await i.response.send_message(embed=embed, view=GuildAdminPanel(), ephemeral=True)

@bot.tree.command(name="สมัครกิล", description="สมัครเข้ากิล Albion Online")
async def apply_cmd(i: discord.Interaction):
    app = get_application(str(i.user.id))
    if app and app.get("status") == "pending":
        await i.response.send_message("⏳ ใบสมัครของคุณกำลังรอการอนุมัติอยู่ค่ะ!", ephemeral=True); return
    if app and app.get("status") == "approved":
        await i.response.send_message("✅ คุณเป็นสมาชิกกิลอยู่แล้วค่ะ!", ephemeral=True); return
    await i.response.send_message(
        embed=discord.Embed(
            title=TEXT["exp_question"],
            description="เลือกได้เลยค่ะ 👇",
            color=CFG["guild_color"]
        ),
        view=Step0ExpView.build(),
        ephemeral=True
    )

@bot.tree.command(name="ดูใบสมัคร", description="ดูสถานะใบสมัครของตัวเอง")
async def check_app(i: discord.Interaction):
    app = get_application(str(i.user.id))
    if not app:
        await i.response.send_message("❌ ยังไม่มีใบสมัครค่ะ! กด /สมัครกิล เพื่อสมัครค่ะ", ephemeral=True)
        return

    status_map   = {"pending": "⏳ รออนุมัติ", "approved": "✅ อนุมัติแล้ว", "rejected": "❌ ไม่ผ่าน"}
    status       = status_map.get(app.get("status", "pending"), "❓")
    status_color = {"pending": 0xf0c040, "approved": 0x2ecc71, "rejected": 0xe74c3c}.get(app.get("status", "pending"), CFG["guild_color"])

    # แปลง roles
    role_text = ", ".join([ROLE_MAP[r][0] for r in app.get("roles", "").split(",") if r in ROLE_MAP]) or "ไม่ระบุ"

    # แปลง activities
    activity_text = ", ".join([get_activity_map()[a] for a in app.get("activities", "").split(",") if a in get_activity_map()]) or "ไม่ระบุ"

    # แปลง experience
    exp_text = get_exp_map().get(app.get("experience", ""), "ไม่ระบุ")

    # แปลง playtimes
    time_text = ", ".join([TIME_MAP[t] for t in app.get("playtimes", "").split(",") if t in TIME_MAP]) or "ไม่ระบุ"

    embed = discord.Embed(title="📋 ใบสมัครของฉัน", color=status_color)
    embed.set_thumbnail(url=i.user.display_avatar.url)
    embed.add_field(name="🗡️ Albion Name",  value=f"**{app.get('albion_name', '?')}**", inline=True)
    embed.add_field(name="🏷️ ชื่อเล่น",      value=app.get("item_power", "ไม่ระบุ"),    inline=True)
    embed.add_field(name="📊 สถานะ",         value=status,                               inline=True)
    embed.add_field(name="🛡️ บทบาท",         value=role_text,                            inline=False)
    embed.add_field(name="🎮 กิจกรรม",       value=activity_text,                        inline=False)
    embed.add_field(name="📈 ประสบการณ์",    value=exp_text,                             inline=True)
    embed.add_field(name="⏰ เวลาเล่น",      value=time_text,                            inline=True)
    if app.get("about"):
        embed.add_field(name="🏰 กิลเก่า",    value=app["about"],                         inline=False)

    # แสดงข้อมูลผู้ตรวจถ้าถูกตรวจแล้ว
    if app.get("reviewed_by"):
        reviewed_at = app.get("reviewed_at", "")[:10] if app.get("reviewed_at") else "?"
        embed.add_field(name="👤 ตรวจโดย", value=f"{app['reviewed_by']} ({reviewed_at})", inline=False)

    # แสดงรูปสกรีนช็อตถ้ามี
    if app.get("screenshot_url"):
        embed.add_field(name="🖼️ สกรีนช็อต IP", value="[ดูรูป](" + app["screenshot_url"] + ")", inline=False)
        embed.set_image(url=app["screenshot_url"])

    embed.add_field(name="📅 สมัครเมื่อ", value=app.get("created_at", "?")[:10], inline=True)
    embed.set_footer(text=f"Discord: {app.get('discord_name', '?')}")
    await i.response.send_message(embed=embed, ephemeral=True)



# ══════════════════════════════════════════════════════════
# EVENT / CONTENT SYSTEM
# ══════════════════════════════════════════════════════════
import zoneinfo

TZ_BKK = zoneinfo.ZoneInfo("Asia/Bangkok")
CH_EVENT = int(env("CH_EVENT", 0))   # ห้องโพสต์การ์ด event

# ─── DB helpers ───────────────────────────────────────────
def create_event(data: dict):
    try:
        r = get_sb().table("guild_events").insert(data).execute()
        return r.data[0] if r.data else None
    except Exception as e: print(f"❌ create_event: {e}"); return None

def get_event(event_id: int):
    try:
        r = get_sb().table("guild_events").select("*").eq("id", event_id).single().execute()
        return r.data
    except: return None

def update_event_message(event_id: int, message_id: int):
    try: get_sb().table("guild_events").update({"message_id": message_id}).eq("id", event_id).execute()
    except: pass

def get_signups(event_id: int):
    try:
        r = get_sb().table("event_signups").select("*").eq("event_id", event_id).order("signed_at").execute()
        return r.data or []
    except: return []

def get_my_signup(event_id: int, uid: str):
    try:
        r = get_sb().table("event_signups").select("*").eq("event_id", event_id).eq("discord_id", uid).execute()
        return r.data[0] if r.data else None
    except: return None

def add_signup(event_id: int, uid: str, discord_name: str, albion_name: str, role_key: str, waitlist: bool):
    try:
        get_sb().table("event_signups").insert({
            "event_id":     event_id,
            "discord_id":   uid,
            "discord_name": discord_name,
            "albion_name":  albion_name,
            "role_key":     role_key,
            "waitlist":     waitlist,
            "signed_at":    now_iso(),
        }).execute()
        return True
    except Exception as e: print(f"❌ add_signup: {e}"); return False

def remove_signup(event_id: int, uid: str):
    try:
        get_sb().table("event_signups").delete().eq("event_id", event_id).eq("discord_id", uid).execute()
        return True
    except: return False

def promote_waitlist(event_id: int, role_key: str):
    """โปรโมตคนแรกใน waitlist ของ role นั้น"""
    try:
        r = get_sb().table("event_signups")            .select("*").eq("event_id", event_id).eq("role_key", role_key).eq("waitlist", True)            .order("signed_at").limit(1).execute()
        if r.data:
            uid = r.data[0]["discord_id"]
            get_sb().table("event_signups").update({"waitlist": False})                .eq("event_id", event_id).eq("discord_id", uid).execute()
            return r.data[0]
    except: pass
    return None

# ─── Build event embed ────────────────────────────────────
ROLE_EMOJI = {
    "tank":     "🛡️ Tank",
    "healer":   "💚 Healer",
    "melee":    "⚔️ Melee",
    "ranged":   "🏹 Ranged",
    "magic":    "🔮 Magic",
    "gatherer": "⚒️ Gatherer",
    "crafter":  "🔨 Crafter",
    "scout":    "🗺️ Scout",
}

def build_event_embed(ev: dict, signups: list) -> discord.Embed:
    slots  = {k: v for k, v in ev.items() if k.startswith("slot_") and v > 0}
    # นับคนที่ confirmed (ไม่ใช่ waitlist) แยก role
    confirmed = {}
    waiting   = {}
    for s in signups:
        rk = s["role_key"]
        if s["waitlist"]:
            waiting.setdefault(rk, []).append(s)
        else:
            confirmed.setdefault(rk, []).append(s)

    # parse event_time
    try:
        ev_dt  = datetime.fromisoformat(ev["event_time"]).astimezone(TZ_BKK)
        time_str = ev_dt.strftime("%d/%m/%Y %H:%M น.")
    except:
        time_str = ev.get("event_time", "?")

    total_slots     = sum(slots.values())
    total_confirmed = sum(len(v) for v in confirmed.values())

    color = 0x2ecc71 if total_confirmed >= total_slots else CFG["guild_color"]
    embed = discord.Embed(
        title=f"⚔️ {ev['name']}",
        description=f"📅 **{time_str}**\n" + "─"*30,
        color=color
    )
    if ev.get("description"):
        embed.description += f"\n{ev['description']}"

    # ตารางแต่ละ role
    for role_key, max_n in slots.items():
        rk        = role_key.replace("slot_", "")
        label     = ROLE_EMOJI.get(rk, rk.title())
        members   = confirmed.get(rk, [])
        wl        = waiting.get(rk, [])
        filled    = len(members)
        bar_full  = "🟩" * filled + "⬜" * (max_n - filled)
        names     = "\n".join([f"• {s['albion_name']}" for s in members]) or "—"
        val       = f"{bar_full} `{filled}/{max_n}`\n{names}"
        if wl:
            val += f"\n⏳ รอคิว: {', '.join(s['albion_name'] for s in wl)}"
        embed.add_field(name=label, value=val, inline=True)

    embed.set_footer(text=f"Event ID: {ev['id']} • กดปุ่มด้านล่างเพื่อลงชื่อค่ะ")
    return embed

# ─── Signup View ──────────────────────────────────────────
class EventSignupView(discord.ui.View):
    def __init__(self, event_id: int, slots: dict):
        super().__init__(timeout=None)
        self.event_id = event_id
        # สร้างปุ่มแต่ละ role ที่มี slot
        for role_key, max_n in slots.items():
            rk    = role_key.replace("slot_", "")
            label = ROLE_EMOJI.get(rk, rk.title())
            btn   = discord.ui.Button(
                label=label,
                style=discord.ButtonStyle.secondary,
                custom_id=f"event_{event_id}_{rk}",
                row=0 if rk in ("tank","healer","melee") else 1
            )
            btn.callback = self._make_callback(rk, max_n)
            self.add_item(btn)

        # ปุ่มถอนชื่อ
        cancel_btn          = discord.ui.Button(label="❌ ถอนชื่อ", style=discord.ButtonStyle.danger,
                                                custom_id=f"event_{event_id}_cancel", row=2)
        cancel_btn.callback = self._cancel_callback
        self.add_item(cancel_btn)

    def _make_callback(self, role_key: str, max_n: int):
        async def callback(i: discord.Interaction):
            uid = str(i.user.id)

            # เช็คว่าเป็นสมาชิกที่อนุมัติแล้ว
            app = get_application(uid)
            if not app or app.get("status") != "approved":
                await i.response.send_message("❌ เฉพาะสมาชิกกิลที่ผ่านการอนุมัติเท่านั้นนะคะ!", ephemeral=True)
                return

            albion_name = app.get("albion_name", str(i.user))

            # เช็คว่าลงชื่อ role นี้แล้วหรือยัง
            existing = get_my_signup(self.event_id, uid)
            if existing:
                if existing["role_key"] == role_key and not existing["waitlist"]:
                    await i.response.send_message(f"✅ คุณลงชื่อ **{ROLE_EMOJI.get(role_key, role_key)}** ไว้แล้วค่ะ!", ephemeral=True)
                    return
                # เปลี่ยน role — ลบแล้วลงใหม่
                remove_signup(self.event_id, uid)
                # โปรโมต waitlist ของ role เก่า
                promote_waitlist(self.event_id, existing["role_key"])

            # นับ slot ที่ใช้ไปแล้ว
            ev      = get_event(self.event_id)
            signups = get_signups(self.event_id)
            filled  = sum(1 for s in signups if s["role_key"] == role_key and not s["waitlist"])
            waitlist = filled >= max_n

            add_signup(self.event_id, uid, str(i.user), albion_name, role_key, waitlist)

            if waitlist:
                msg = f"⏳ Slot **{ROLE_EMOJI.get(role_key, role_key)}** เต็มแล้วค่ะ ลงชื่อเข้า **waiting list** ไว้ก่อนนะคะ!"
            else:
                msg = f"✅ ลงชื่อ **{ROLE_EMOJI.get(role_key, role_key)}** สำเร็จแล้วค่ะ!"

            await i.response.send_message(msg, ephemeral=True)

            # อัปเดตการ์ด
            await _refresh_event_card(i, self.event_id)

        return callback

    async def _cancel_callback(self, i: discord.Interaction):
        uid      = str(i.user.id)
        existing = get_my_signup(self.event_id, uid)
        if not existing:
            await i.response.send_message("❌ คุณยังไม่ได้ลงชื่อไว้ค่ะ!", ephemeral=True); return

        role_key = existing["role_key"]
        was_wl   = existing["waitlist"]
        remove_signup(self.event_id, uid)

        # โปรโมต waitlist ถ้าคนที่ถอนไม่ใช่ waitlist
        if not was_wl:
            promoted = promote_waitlist(self.event_id, role_key)
            if promoted:
                # DM คนที่ได้รับการโปรโมต
                try:
                    guild  = i.guild
                    member = guild.get_member(int(promoted["discord_id"]))
                    if member:
                        await member.send(embed=discord.Embed(
                            title="🎉 ได้รับการโปรโมตจาก Waiting List!",
                            description=f"มีที่ว่างใน **{ROLE_EMOJI.get(role_key, role_key)}** แล้วค่ะ! คุณได้เข้า event แล้วนะคะ 🎊",
                            color=0x2ecc71
                        ))
                except: pass

        await i.response.send_message("✅ ถอนชื่อเรียบร้อยแล้วค่ะ!", ephemeral=True)
        await _refresh_event_card(i, self.event_id)


async def _refresh_event_card(i: discord.Interaction, event_id: int):
    """อัปเดต embed การ์ดหลังมีการเปลี่ยนแปลง"""
    try:
        ev      = get_event(event_id)
        signups = get_signups(event_id)
        slots   = {k: v for k, v in ev.items() if k.startswith("slot_") and v > 0}
        new_embed = build_event_embed(ev, signups)
        await i.message.edit(embed=new_embed)
    except: pass


# ─── Create Event Modal ───────────────────────────────────
class CreateEventModal(discord.ui.Modal, title="⚔️ สร้าง Event คอนเทนต์"):
    ev_name = discord.ui.TextInput(label="ชื่อ Event", placeholder="เช่น Hellgate ดึก / Group Dungeon เย็น", max_length=60)
    ev_desc = discord.ui.TextInput(label="คำอธิบายเพิ่มเติม (ไม่บังคับ)", required=False, max_length=200,
                                   style=discord.TextStyle.paragraph,
                                   placeholder="เช่น แต่งตัว IP1200+ นะคะ")
    ev_time = discord.ui.TextInput(label="วันเวลา (DD/MM/YYYY HH:MM)", placeholder="เช่น 25/12/2025 20:00", max_length=16)
    slots_a = discord.ui.TextInput(label="Tank / Healer / Melee (ใส่ตัวเลข คั่นด้วย /)",
                                   placeholder="เช่น 2/1/3  (Tank2 Healer1 Melee3)", max_length=10)
    slots_b = discord.ui.TextInput(label="Ranged / Magic / อื่นๆ (0=ไม่ต้องการ)",
                                   placeholder="เช่น 2/2/0  (Ranged2 Magic2)", max_length=10)

    async def on_submit(self, i: discord.Interaction):
        # parse วันเวลา
        try:
            dt_naive = datetime.strptime(self.ev_time.value.strip(), "%d/%m/%Y %H:%M")
            dt_bkk   = dt_naive.replace(tzinfo=TZ_BKK)
            dt_iso   = dt_bkk.isoformat()
        except:
            await i.response.send_message("❌ รูปแบบวันเวลาไม่ถูกต้องค่ะ ใช้ DD/MM/YYYY HH:MM นะคะ", ephemeral=True)
            return

        # parse slots
        def parse3(s):
            parts = [p.strip() for p in s.split("/")]
            return [int(p) if p.isdigit() else 0 for p in (parts + ["0","0","0"])[:3]]

        a = parse3(self.slots_a.value)
        b = parse3(self.slots_b.value)
        slot_map = {"tank": a[0], "healer": a[1], "melee": a[2],
                    "ranged": b[0], "magic": b[1]}
        if all(v == 0 for v in slot_map.values()):
            await i.response.send_message("❌ ต้องมีอย่างน้อย 1 role ค่ะ!", ephemeral=True); return

        # บันทึก DB
        ev = create_event({
            "name":        self.ev_name.value.strip(),
            "description": self.ev_desc.value.strip(),
            "event_time":  dt_iso,
            "slot_tank":   slot_map["tank"],
            "slot_healer": slot_map["healer"],
            "slot_melee":  slot_map["melee"],
            "slot_ranged": slot_map["ranged"],
            "slot_magic":  slot_map["magic"],
            "created_by":  str(i.user),
            "status":      "open",
        })
        if not ev:
            await i.response.send_message("❌ บันทึก event ไม่สำเร็จ ลองใหม่ค่ะ!", ephemeral=True); return

        # โพสต์การ์ดไปห้อง event
        event_ch = bot.get_channel(CH_EVENT)
        if not event_ch:
            await i.response.send_message("❌ ไม่พบห้อง CH_EVENT ค่ะ ตั้งค่าใน .env ก่อนนะคะ!", ephemeral=True); return

        slots     = {f"slot_{k}": v for k, v in slot_map.items() if v > 0}
        view      = EventSignupView(ev["id"], slots)
        card_msg  = await event_ch.send(embed=build_event_embed(ev, []), view=view)
        update_event_message(ev["id"], card_msg.id)

        # ตั้ง reminder task
        bot.loop.create_task(_event_reminder(ev["id"], dt_bkk))

        await i.response.send_message(
            f"✅ สร้าง event **{ev['name']}** แล้วค่ะ! ส่งการ์ดไปที่ {event_ch.mention} แล้วนะคะ",
            ephemeral=True
        )
        await log_action("CREATE_EVENT", f"{i.user} สร้าง: {ev['name']} @ {self.ev_time.value}", 0x9b59b6)


async def _event_reminder(event_id: int, event_dt: datetime):
    """ส่ง ping + DM ก่อน event 30 นาที"""
    now_bkk   = datetime.now(TZ_BKK)
    remind_at = event_dt - timedelta(minutes=30)
    wait_secs = (remind_at - now_bkk).total_seconds()
    if wait_secs > 0:
        await asyncio.sleep(wait_secs)

    ev      = get_event(event_id)
    signups = get_signups(event_id)
    if not ev or ev.get("status") != "open": return

    event_ch = bot.get_channel(CH_EVENT)
    if not event_ch: return

    confirmed = [s for s in signups if not s["waitlist"]]
    mentions  = " ".join([f"<@{s['discord_id']}>" for s in confirmed])

    await event_ch.send(
        content=f"⏰ **แจ้งเตือน! Event เริ่มใน 30 นาทีค่ะ!**\n{mentions}",
        embed=discord.Embed(
            title=f"⚔️ {ev['name']} — เริ่มในอีก 30 นาที!",
            description="เตรียมตัวให้พร้อมนะคะ!",
            color=0xe74c3c
        )
    )

    # DM แต่ละคน
    for s in confirmed:
        try:
            guilds = [g for g in bot.guilds]
            for g in guilds:
                member = g.get_member(int(s["discord_id"]))
                if member:
                    await member.send(embed=discord.Embed(
                        title=f"⏰ {ev['name']} เริ่มในอีก 30 นาทีนะคะ!",
                        description="เตรียมตัวและ login เข้าเกมได้เลยค่ะ 🎮",
                        color=0xe74c3c
                    ))
                    break
        except: pass

    await log_action("REMINDER_SENT", f"Event: {ev['name']}", 0xe74c3c)


# ─── Slash Commands ───────────────────────────────────────
@bot.tree.command(name="สร้างevent", description="สร้าง Event คอนเทนต์ประจำวัน")
async def create_event_cmd(i: discord.Interaction):
    if not is_admin(i):
        await i.response.send_message("❌ ไม่มีสิทธิ์ค่ะ!", ephemeral=True); return
    await i.response.send_modal(CreateEventModal())


@bot.tree.command(name="ยกเลิกevent", description="ปิด Event (แอดมินเท่านั้น)")
@app_commands.describe(event_id="ID ของ event ที่ต้องการยกเลิก")
async def cancel_event_cmd(i: discord.Interaction, event_id: int):
    if not is_admin(i):
        await i.response.send_message("❌ ไม่มีสิทธิ์ค่ะ!", ephemeral=True); return
    try:
        get_sb().table("guild_events").update({"status": "cancelled"}).eq("id", event_id).execute()
        await i.response.send_message(f"✅ ยกเลิก Event ID {event_id} แล้วค่ะ!", ephemeral=True)
        await log_action("CANCEL_EVENT", f"Event ID: {event_id} ยกเลิกโดย {i.user}", 0xe74c3c)
    except Exception as e:
        await i.response.send_message(f"❌ {e}", ephemeral=True)


@bot.tree.command(name="ดูevent", description="ดู Event ที่กำลังเปิดอยู่ทั้งหมด")
async def list_events_cmd(i: discord.Interaction):
    try:
        r = get_sb().table("guild_events").select("*").eq("status", "open").order("event_time").execute()
        events = r.data or []
        if not events:
            await i.response.send_message("ไม่มี event ที่เปิดอยู่ตอนนี้ค่ะ!", ephemeral=True); return
        lines = []
        for ev in events:
            try:
                dt  = datetime.fromisoformat(ev["event_time"]).astimezone(TZ_BKK)
                ts  = dt.strftime("%d/%m %H:%M")
            except:
                ts  = ev.get("event_time","?")[:16]
            signups = get_signups(ev["id"])
            cnt     = sum(1 for s in signups if not s["waitlist"])
            total   = sum(v for k, v in ev.items() if k.startswith("slot_") and v)
            lines.append(f"**{ev['name']}** — {ts} น. | {cnt}/{total} คน | ID: `{ev['id']}`")
        embed = discord.Embed(title="📅 Event ที่เปิดอยู่", description="\n".join(lines), color=CFG["guild_color"])
        await i.response.send_message(embed=embed, ephemeral=True)
    except Exception as e:
        await i.response.send_message(f"❌ {e}", ephemeral=True)

# ══════════════════════════════════════
# RUN
# ══════════════════════════════════════
bot.run(DISCORD_TOKEN, reconnect=True, log_handler=None)
